import SwiftUI
import Charts

struct RaceDetailView: View {
    let viewModel: TianxiViewModel

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                TianxiCard {
                    VStack(alignment: .leading, spacing: 18) {
                        SectionHeaderView(
                            eyebrow: "Race detail",
                            title: "第\(viewModel.selectedRace.number)場 · \(viewModel.selectedRace.title)",
                            subtitle: "\(viewModel.selectedRace.distance)m · \(viewModel.selectedRace.className) · \(viewModel.selectedRace.trackCondition)"
                        )

                        HStack(spacing: 16) {
                            MetricBadgeView(title: "Start", value: viewModel.selectedRace.startTime, symbol: "clock")
                            MetricBadgeView(title: "Prize", value: viewModel.selectedRace.purseText, symbol: "banknote")
                        }
                    }
                }

                TianxiCard {
                    VStack(alignment: .leading, spacing: 16) {
                        SectionHeaderView(
                            eyebrow: "AI suggestion panel",
                            title: "建議投注組合",
                            subtitle: "1-2-3、單T、四重彩一眼睇清"
                        )

                        ForEach(viewModel.selectedRace.suggestions) { suggestion in
                            VStack(alignment: .leading, spacing: 8) {
                                HStack {
                                    Text(suggestion.title)
                                        .font(.headline.weight(.semibold))
                                        .foregroundStyle(.white)
                                    Spacer()
                                    Text(suggestion.confidenceText)
                                        .font(.caption.weight(.semibold))
                                        .foregroundStyle(TianxiPalette.gold)
                                }

                                Text(suggestion.picks)
                                    .font(.title3.weight(.bold))
                                    .foregroundStyle(TianxiPalette.emerald)

                                Text(suggestion.note)
                                    .font(.subheadline)
                                    .foregroundStyle(TianxiPalette.muted)
                            }
                            .padding(16)
                            .background(TianxiPalette.surface, in: .rect(cornerRadius: 20))
                        }
                    }
                }

                TianxiCard {
                    VStack(alignment: .leading, spacing: 16) {
                        SectionHeaderView(
                            eyebrow: "Prediction charts",
                            title: "Odds movement · Win probabilities",
                            subtitle: "盤口變化與 AI 排名同步顯示"
                        )

                        Chart(viewModel.selectedRace.oddsMovement) { point in
                            LineMark(
                                x: .value("Time", point.label),
                                y: .value("Odds", point.value)
                            )
                            .interpolationMethod(.catmullRom)
                            .lineStyle(.init(lineWidth: 3, lineCap: .round))
                            .foregroundStyle(TianxiPalette.gold)

                            PointMark(
                                x: .value("Time", point.label),
                                y: .value("Odds", point.value)
                            )
                            .foregroundStyle(TianxiPalette.gold)
                        }
                        .frame(height: 180)
                        .chartYAxis {
                            AxisMarks(position: .leading) { value in
                                AxisGridLine(stroke: .init(lineWidth: 0.6))
                                    .foregroundStyle(.white.opacity(0.08))
                                AxisValueLabel()
                                    .foregroundStyle(TianxiPalette.muted)
                            }
                        }
                        .chartXAxis {
                            AxisMarks { value in
                                AxisValueLabel()
                                    .foregroundStyle(TianxiPalette.muted)
                            }
                        }
                        .chartPlotStyle { plot in
                            plot.background(TianxiPalette.surface.opacity(0.75))
                                .clipShape(.rect(cornerRadius: 18))
                        }

                        Chart(viewModel.selectedRace.predictions) { point in
                            BarMark(
                                x: .value("Horse", point.label),
                                y: .value("Probability", point.winProbability)
                            )
                            .foregroundStyle(
                                LinearGradient(
                                    colors: [TianxiPalette.emerald, TianxiPalette.gold],
                                    startPoint: .bottom,
                                    endPoint: .top
                                )
                            )
                            .clipShape(.rect(cornerRadius: 8))
                        }
                        .frame(height: 180)
                        .chartYAxis(.hidden)
                        .chartXAxis {
                            AxisMarks { value in
                                AxisValueLabel()
                                    .foregroundStyle(TianxiPalette.muted)
                            }
                        }
                        .chartPlotStyle { plot in
                            plot.background(TianxiPalette.surface.opacity(0.75))
                                .clipShape(.rect(cornerRadius: 18))
                        }
                    }
                }

                TianxiCard {
                    VStack(alignment: .leading, spacing: 14) {
                        SectionHeaderView(
                            eyebrow: "Horse list",
                            title: "馬匹名單與 AI 分數",
                            subtitle: "Draw, jockey, trainer, odds and factor-level scores"
                        )

                        ForEach(viewModel.selectedRace.horses) { horse in
                            VStack(alignment: .leading, spacing: 12) {
                                HStack(alignment: .top) {
                                    VStack(alignment: .leading, spacing: 6) {
                                        Text("\(horse.number)號 \(horse.name)")
                                            .font(.headline.weight(.bold))
                                            .foregroundStyle(.white)
                                        Text("檔位 \(horse.draw) · 騎師 \(horse.jockey) · 練馬師 \(horse.trainer)")
                                            .font(.subheadline)
                                            .foregroundStyle(TianxiPalette.muted)
                                    }

                                    Spacer()

                                    VStack(alignment: .trailing, spacing: 6) {
                                        Text("\(horse.odds, format: .number.precision(.fractionLength(1)))x")
                                            .font(.headline.weight(.bold))
                                            .foregroundStyle(TianxiPalette.gold)
                                        Text("AI \(horse.aiScore)")
                                            .font(.caption.weight(.semibold))
                                            .foregroundStyle(TianxiPalette.emerald)
                                    }
                                }

                                HStack(spacing: 10) {
                                    scorePill(label: "Pace", score: horse.paceScore)
                                    scorePill(label: "Form", score: horse.formScore)
                                    scorePill(label: "Blood", score: horse.bloodlineScore)
                                    scorePill(label: "Work", score: horse.trackworkScore)
                                }

                                Text(horse.verdict)
                                    .font(.subheadline)
                                    .foregroundStyle(.white.opacity(0.84))
                            }
                            .padding(16)
                            .background(TianxiPalette.surface, in: .rect(cornerRadius: 20))
                        }
                    }
                }
            }
            .padding(.horizontal, 16)
            .padding(.top, 12)
            .padding(.bottom, 120)
        }
        .background(PremiumBackgroundView())
    }

    private func scorePill(label: String, score: Int) -> some View {
        VStack(alignment: .leading, spacing: 3) {
            Text(label)
                .font(.caption2.weight(.medium))
                .foregroundStyle(TianxiPalette.muted)
            Text("\(score)")
                .font(.subheadline.weight(.bold))
                .foregroundStyle(.white)
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 8)
        .background(TianxiPalette.elevated, in: .capsule)
    }
}
