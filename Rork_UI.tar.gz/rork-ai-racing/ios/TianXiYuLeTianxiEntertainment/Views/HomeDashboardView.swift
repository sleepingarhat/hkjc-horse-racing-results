import SwiftUI
import Charts

struct HomeDashboardView: View {
    let viewModel: TianxiViewModel
    let onOpenRace: (Race) -> Void
    let onOpenChat: () -> Void

    private let columns: [GridItem] = [
        GridItem(.flexible(), spacing: 14),
        GridItem(.flexible(), spacing: 14)
    ]

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                TianxiCard {
                    VStack(alignment: .leading, spacing: 18) {
                        HStack(alignment: .top) {
                            BrandHeaderView(subtitle: "Premium Hong Kong horse racing AI analysis")
                            Spacer(minLength: 12)
                            VStack(alignment: .trailing, spacing: 8) {
                                Label(viewModel.meeting.venue, systemImage: "figure.equestrian.sports")
                                Label(viewModel.meeting.surface, systemImage: "flag.pattern.checkered")
                            }
                            .font(.caption.weight(.medium))
                            .foregroundStyle(TianxiPalette.muted)
                        }

                        Text(viewModel.meeting.highlight)
                            .font(.body)
                            .foregroundStyle(.white.opacity(0.9))

                        HStack(spacing: 12) {
                            MetricBadgeView(title: "Today", value: viewModel.meeting.dateText, symbol: "calendar")
                            MetricBadgeView(title: "Weather", value: viewModel.meeting.weather, symbol: "cloud.moon")
                        }
                    }
                }

                TianxiCard {
                    VStack(alignment: .leading, spacing: 16) {
                        SectionHeaderView(
                            eyebrow: "Today’s race meeting",
                            title: "焦點場次 · 第\(viewModel.selectedRace.number)場",
                            subtitle: "\(viewModel.selectedRace.title) · \(viewModel.selectedRace.distance)m · AI confidence \(viewModel.selectedRace.aiConfidence)%"
                        )

                        HStack(spacing: 12) {
                            VStack(alignment: .leading, spacing: 6) {
                                Text("\(viewModel.selectedRace.className)")
                                    .font(.headline.weight(.semibold))
                                    .foregroundStyle(.white)
                                Text(viewModel.selectedRace.purseText)
                                    .font(.subheadline)
                                    .foregroundStyle(TianxiPalette.muted)
                            }
                            Spacer()
                            Button("查看詳情") {
                                onOpenRace(viewModel.selectedRace)
                            }
                            .buttonStyle(.borderedProminent)
                            .tint(TianxiPalette.emerald)
                        }
                    }
                }

                TianxiCard {
                    VStack(alignment: .leading, spacing: 14) {
                        SectionHeaderView(
                            eyebrow: "Quick AI chat",
                            title: "即時賽事提問",
                            subtitle: "支援自然語言：單T、騎師王、六環彩、步速分析"
                        )

                        HStack(spacing: 12) {
                            TextField("例如：第三場單T兩膽4腳建議", text: Binding(
                                get: { viewModel.quickPrompt },
                                set: { viewModel.quickPrompt = $0 }
                            ))
                            .textFieldStyle(.plain)
                            .foregroundStyle(.white)
                            .padding(.horizontal, 14)
                            .padding(.vertical, 14)
                            .background(TianxiPalette.surface, in: .rect(cornerRadius: 18))

                            Button {
                                viewModel.sendQuickPrompt()
                                onOpenChat()
                            } label: {
                                Image(systemName: "arrow.up.right.circle.fill")
                                    .font(.title2)
                            }
                            .buttonStyle(.plain)
                            .foregroundStyle(TianxiPalette.gold)
                            .frame(width: 48, height: 48)
                            .background(TianxiPalette.gold.opacity(0.12), in: .circle)
                        }
                    }
                }

                VStack(alignment: .leading, spacing: 14) {
                    SectionHeaderView(
                        eyebrow: "Race cards",
                        title: "數據賽卡",
                        subtitle: "Mobile-friendly, fast-glance race cards for today’s key races"
                    )

                    LazyVGrid(columns: columns, spacing: 14) {
                        ForEach(viewModel.meeting.races) { race in
                            Button {
                                onOpenRace(race)
                            } label: {
                                TianxiCard {
                                    VStack(alignment: .leading, spacing: 12) {
                                        HStack {
                                            Text("R\(race.number)")
                                                .font(.headline.weight(.bold))
                                                .foregroundStyle(.black)
                                                .padding(.horizontal, 10)
                                                .padding(.vertical, 6)
                                                .background(TianxiPalette.gold, in: .capsule)
                                            Spacer()
                                            Text(race.startTime)
                                                .font(.caption.weight(.semibold))
                                                .foregroundStyle(TianxiPalette.muted)
                                        }

                                        Text(race.title)
                                            .font(.headline.weight(.semibold))
                                            .multilineTextAlignment(.leading)
                                            .foregroundStyle(.white)

                                        Text("\(race.distance)m · \(race.className)")
                                            .font(.subheadline)
                                            .foregroundStyle(TianxiPalette.muted)

                                        HStack {
                                            VStack(alignment: .leading, spacing: 4) {
                                                Text("AI Score")
                                                    .font(.caption)
                                                    .foregroundStyle(TianxiPalette.muted)
                                                Text("\(race.aiConfidence)")
                                                    .font(.title3.weight(.bold))
                                                    .foregroundStyle(TianxiPalette.emerald)
                                            }
                                            Spacer()
                                            Image(systemName: "chart.line.uptrend.xyaxis")
                                                .font(.title2)
                                                .foregroundStyle(TianxiPalette.gold)
                                        }
                                    }
                                }
                            }
                            .buttonStyle(.plain)
                        }
                    }
                }

                TianxiCard {
                    VStack(alignment: .leading, spacing: 16) {
                        SectionHeaderView(
                            eyebrow: "Market intelligence",
                            title: "Pace trend · Odds flow",
                            subtitle: "Charts tuned for at-a-glance analysis"
                        )

                        Chart(viewModel.selectedRace.paceTrend) { point in
                            AreaMark(
                                x: .value("Section", point.label),
                                y: .value("Pace", point.value)
                            )
                            .interpolationMethod(.catmullRom)
                            .foregroundStyle(
                                LinearGradient(
                                    colors: [TianxiPalette.emerald.opacity(0.45), .clear],
                                    startPoint: .top,
                                    endPoint: .bottom
                                )
                            )

                            LineMark(
                                x: .value("Section", point.label),
                                y: .value("Pace", point.value)
                            )
                            .interpolationMethod(.catmullRom)
                            .lineStyle(.init(lineWidth: 3, lineCap: .round, lineJoin: .round))
                            .foregroundStyle(
                                LinearGradient(
                                    colors: [TianxiPalette.gold, TianxiPalette.emerald],
                                    startPoint: .leading,
                                    endPoint: .trailing
                                )
                            )
                        }
                        .frame(height: 190)
                        .chartYAxis(.hidden)
                        .chartXAxis {
                            AxisMarks { value in
                                AxisValueLabel()
                                    .foregroundStyle(TianxiPalette.muted)
                            }
                        }
                        .chartPlotStyle { plot in
                            plot
                                .background(TianxiPalette.surface.opacity(0.75))
                                .clipShape(.rect(cornerRadius: 18))
                        }
                    }
                }
            }
            .padding(.horizontal, 16)
            .padding(.top, 12)
            .padding(.bottom, 120)
        }
        .background(PremiumBackgroundView())
    }
}
