import SwiftUI

struct FactorAnalysisView: View {
    let viewModel: TianxiViewModel

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                TianxiCard {
                    SectionHeaderView(
                        eyebrow: "Factor analysis",
                        title: "模型因子面板",
                        subtitle: "Draw, Pace, Form, Bloodline, Morning Trackwork and money flow"
                    )
                }

                VStack(alignment: .leading, spacing: 14) {
                    Text("選擇因子")
                        .font(.headline.weight(.semibold))
                        .foregroundStyle(.white)

                    LazyVGrid(columns: [GridItem(.adaptive(minimum: 140), spacing: 12)], spacing: 12) {
                        ForEach(viewModel.factors) { factor in
                            Button {
                                viewModel.toggleFactor(factor)
                            } label: {
                                HStack(spacing: 10) {
                                    Image(systemName: factor.symbol)
                                        .foregroundStyle(viewModel.selectedFactorNames.contains(factor.name) ? .black : TianxiPalette.gold)
                                    Text(factor.name)
                                        .font(.subheadline.weight(.semibold))
                                    Spacer(minLength: 0)
                                }
                                .foregroundStyle(viewModel.selectedFactorNames.contains(factor.name) ? .black : .white)
                                .padding(14)
                                .background(
                                    viewModel.selectedFactorNames.contains(factor.name)
                                    ? AnyShapeStyle(TianxiPalette.gold)
                                    : AnyShapeStyle(TianxiPalette.surface),
                                    in: .rect(cornerRadius: 18)
                                )
                            }
                            .buttonStyle(.plain)
                        }
                    }
                }

                ForEach(viewModel.selectedFactors) { factor in
                    TianxiCard {
                        VStack(alignment: .leading, spacing: 12) {
                            HStack {
                                Label(factor.name, systemImage: factor.symbol)
                                    .font(.headline.weight(.semibold))
                                    .foregroundStyle(.white)
                                Spacer()
                                Text("Weight \(factor.weight)")
                                    .font(.caption.weight(.bold))
                                    .foregroundStyle(TianxiPalette.gold)
                            }

                            GeometryReader { proxy in
                                let width = max(proxy.size.width, 0)
                                ZStack(alignment: .leading) {
                                    Capsule()
                                        .fill(TianxiPalette.surface)
                                    Capsule()
                                        .fill(LinearGradient(colors: [TianxiPalette.emerald, TianxiPalette.gold], startPoint: .leading, endPoint: .trailing))
                                        .frame(width: width * (Double(factor.weight) / 100.0))
                                }
                            }
                            .frame(height: 10)

                            Text(factor.summary)
                                .font(.subheadline)
                                .foregroundStyle(.white.opacity(0.84))
                        }
                    }
                }
            }
            .padding(.horizontal, 16)
            .padding(.top, 12)
            .padding(.bottom, 120)
        }
        .background(PremiumBackgroundView())
    }
}
