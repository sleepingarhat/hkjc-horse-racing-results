import SwiftUI

nonisolated enum TianxiPalette {
    static let background = Color(red: 0.04, green: 0.04, blue: 0.05)
    static let surface = Color(red: 0.09, green: 0.09, blue: 0.10)
    static let elevated = Color(red: 0.13, green: 0.13, blue: 0.14)
    static let gold = Color(red: 0.86, green: 0.73, blue: 0.41)
    static let emerald = Color(red: 0.10, green: 0.62, blue: 0.43)
    static let muted = Color(red: 0.60, green: 0.62, blue: 0.65)
}

struct PremiumBackgroundView: View {
    var body: some View {
        ZStack {
            TianxiPalette.background
                .ignoresSafeArea()

            LinearGradient(
                colors: [
                    TianxiPalette.gold.opacity(0.18),
                    .clear,
                    TianxiPalette.emerald.opacity(0.14)
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .blur(radius: 60)
            .ignoresSafeArea()

            Rectangle()
                .fill(.black.opacity(0.22))
                .background(.ultraThinMaterial)
                .ignoresSafeArea()
        }
    }
}

struct TianxiCard<Content: View>: View {
    let content: Content

    init(@ViewBuilder content: () -> Content) {
        self.content = content()
    }

    var body: some View {
        content
            .padding(18)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(
                LinearGradient(
                    colors: [
                        TianxiPalette.elevated.opacity(0.96),
                        TianxiPalette.surface.opacity(0.92)
                    ],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                ),
                in: .rect(cornerRadius: 24)
            )
            .overlay {
                RoundedRectangle(cornerRadius: 24)
                    .strokeBorder(TianxiPalette.gold.opacity(0.18), lineWidth: 1)
            }
            .shadow(color: .black.opacity(0.28), radius: 20, y: 14)
    }
}

struct SectionHeaderView: View {
    let eyebrow: String
    let title: String
    let subtitle: String

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(eyebrow.uppercased())
                .font(.caption.weight(.semibold))
                .tracking(1.6)
                .foregroundStyle(TianxiPalette.gold)
            Text(title)
                .font(.title2.weight(.bold))
                .foregroundStyle(.white)
            Text(subtitle)
                .font(.subheadline)
                .foregroundStyle(TianxiPalette.muted)
        }
    }
}

struct BrandHeaderView: View {
    let subtitle: String

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text("天喜娛樂")
                .font(.system(.largeTitle, design: .default, weight: .heavy))
                .tracking(1.5)
                .foregroundStyle(
                    LinearGradient(
                        colors: [TianxiPalette.gold, .white.opacity(0.92)],
                        startPoint: .leading,
                        endPoint: .trailing
                    )
                )
            Text("Tianxi Entertainment")
                .font(.footnote.weight(.semibold))
                .tracking(1.8)
                .foregroundStyle(TianxiPalette.muted)
            Text(subtitle)
                .font(.subheadline)
                .foregroundStyle(.white.opacity(0.84))
        }
    }
}

struct MetricBadgeView: View {
    let title: String
    let value: String
    let symbol: String

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: symbol)
                .font(.headline)
                .foregroundStyle(TianxiPalette.gold)
                .frame(width: 36, height: 36)
                .background(TianxiPalette.gold.opacity(0.14), in: .circle)

            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(.caption)
                    .foregroundStyle(TianxiPalette.muted)
                Text(value)
                    .font(.headline.weight(.semibold))
                    .foregroundStyle(.white)
            }

            Spacer(minLength: 0)
        }
    }
}
