import SwiftUI

struct AIChatView: View {
    let viewModel: TianxiViewModel

    private let suggestions: [String] = [
        "第三場單T兩膽4腳建議",
        "今日騎師王推薦",
        "六環彩每場選2匹",
        "第三場步速偏快邊匹最受惠"
    ]

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                TianxiCard {
                    VStack(alignment: .leading, spacing: 16) {
                        SectionHeaderView(
                            eyebrow: "AI analysis chat",
                            title: "賽事自然語言分析",
                            subtitle: "Ask like a professional punter, get structured racing insights"
                        )

                        Text("支援例句：第三場單T兩膽4腳建議、今日騎師王推薦、六環彩每場選2匹")
                            .font(.subheadline)
                            .foregroundStyle(.white.opacity(0.84))
                    }
                }

                TianxiCard {
                    VStack(alignment: .leading, spacing: 12) {
                        HStack(spacing: 10) {
                            ForEach(suggestions, id: \.self) { suggestion in
                                Button(suggestion) {
                                    viewModel.quickPrompt = suggestion
                                    viewModel.sendQuickPrompt()
                                }
                                .buttonStyle(.plain)
                                .font(.caption.weight(.semibold))
                                .foregroundStyle(.white)
                                .padding(.horizontal, 12)
                                .padding(.vertical, 10)
                                .background(TianxiPalette.surface, in: .capsule)
                            }
                        }
                    }
                }

                TianxiCard {
                    VStack(spacing: 14) {
                        ForEach(viewModel.chatMessages) { message in
                            HStack {
                                if message.role == .assistant {
                                    messageBubble(message.text, isAssistant: true)
                                    Spacer(minLength: 30)
                                } else {
                                    Spacer(minLength: 30)
                                    messageBubble(message.text, isAssistant: false)
                                }
                            }
                        }
                    }
                }

                TianxiCard {
                    VStack(alignment: .leading, spacing: 12) {
                        HStack(spacing: 12) {
                            TextField("輸入你的分析問題", text: Binding(
                                get: { viewModel.quickPrompt },
                                set: { viewModel.quickPrompt = $0 }
                            ))
                            .textFieldStyle(.plain)
                            .foregroundStyle(.white)
                            .padding(.horizontal, 14)
                            .padding(.vertical, 14)
                            .background(TianxiPalette.surface, in: .rect(cornerRadius: 18))

                            Button("發送") {
                                viewModel.sendQuickPrompt()
                            }
                            .buttonStyle(.borderedProminent)
                            .tint(TianxiPalette.emerald)
                        }
                    }
                }
            }
            .padding(.horizontal, 16)
            .padding(.top, 12)
            .padding(.bottom, 120)
        }
        .background(PremiumBackgroundView())
    }

    private func messageBubble(_ text: String, isAssistant: Bool) -> some View {
        Text(text)
            .font(.body)
            .foregroundStyle(.white)
            .padding(16)
            .background(
                isAssistant
                ? AnyShapeStyle(LinearGradient(colors: [TianxiPalette.elevated, TianxiPalette.surface], startPoint: .topLeading, endPoint: .bottomTrailing))
                : AnyShapeStyle(LinearGradient(colors: [TianxiPalette.emerald.opacity(0.92), TianxiPalette.gold.opacity(0.48)], startPoint: .topLeading, endPoint: .bottomTrailing)),
                in: .rect(cornerRadius: 22)
            )
            .overlay {
                RoundedRectangle(cornerRadius: 22)
                    .strokeBorder(.white.opacity(isAssistant ? 0.08 : 0.12), lineWidth: 1)
            }
    }
}
