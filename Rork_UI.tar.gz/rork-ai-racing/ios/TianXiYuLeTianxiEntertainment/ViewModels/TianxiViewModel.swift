import Foundation
import Observation

@MainActor
@Observable
final class TianxiViewModel {
    let meeting: RaceMeeting = .sample
    let factors: [AnalysisFactor] = AnalysisFactor.samples
    var selectedRaceID: Race.ID
    var selectedFactorNames: Set<String>
    var chatMessages: [ChatMessage]
    var quickPrompt: String

    init() {
        let meeting = RaceMeeting.sample
        self.selectedRaceID = meeting.races.first?.id ?? UUID()
        self.selectedFactorNames = Set(AnalysisFactor.samples.prefix(3).map(\.name))
        self.quickPrompt = "第三場單T兩膽4腳建議"
        self.chatMessages = [
            ChatMessage(id: UUID(), role: .assistant, text: "歡迎來到天喜娛樂。今日第三場最強 AI 主膽為 1 號翠綠迅駒，單T建議以 1、4 做膽，配 7、9、11、12。"),
            ChatMessage(id: UUID(), role: .user, text: "今日騎師王推薦"),
            ChatMessage(id: UUID(), role: .assistant, text: "今日騎師王首選潘頓，重點場次為第 3 場 1 號與第 7 場 2 號。若走穩健路線，可優先組合 1-4-7 與 2-5-8。")
        ]
    }

    var selectedRace: Race {
        meeting.races.first(where: { $0.id == selectedRaceID }) ?? meeting.races[0]
    }

    var selectedFactors: [AnalysisFactor] {
        factors.filter { selectedFactorNames.contains($0.name) }
    }

    func selectRace(_ race: Race) {
        selectedRaceID = race.id
    }

    func toggleFactor(_ factor: AnalysisFactor) {
        if selectedFactorNames.contains(factor.name) {
            selectedFactorNames.remove(factor.name)
        } else {
            selectedFactorNames.insert(factor.name)
        }
    }

    func sendQuickPrompt() {
        let trimmed = quickPrompt.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }

        chatMessages.append(ChatMessage(id: UUID(), role: .user, text: trimmed))
        chatMessages.append(ChatMessage(id: UUID(), role: .assistant, text: response(for: trimmed)))
        quickPrompt = ""
    }

    private func response(for prompt: String) -> String {
        if prompt.contains("單T") {
            return "第三場單T建議：膽 1、4；腳 7、9、11、12。若想壓縮成本，可刪減 12 號。"
        }

        if prompt.contains("騎師王") {
            return "今日騎師王推薦：潘頓、布文、霍宏聲。主力場次集中第 3 場與第 7 場。"
        }

        if prompt.contains("六環彩") {
            return "六環彩保守版：每場選 2 匹時，建議優先鎖定模型前二分數馬，再加一匹冷門保險於高變數場。"
        }

        return "根據目前盤口、步速與晨操資料，第三場仍是今日最值得重點關注的 AI 焦點場。"
    }
}

nonisolated struct ChatMessage: Identifiable, Hashable, Sendable {
    let id: UUID
    let role: ChatRole
    let text: String
}

nonisolated enum ChatRole: String, Hashable, Sendable {
    case user
    case assistant
}
