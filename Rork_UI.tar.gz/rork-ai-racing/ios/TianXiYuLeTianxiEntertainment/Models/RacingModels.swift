import Foundation

nonisolated struct RaceMeeting: Identifiable, Hashable, Sendable {
    let id: UUID
    let venue: String
    let title: String
    let dateText: String
    let surface: String
    let weather: String
    let highlight: String
    let races: [Race]
}

nonisolated struct Race: Identifiable, Hashable, Sendable {
    let id: UUID
    let number: Int
    let title: String
    let distance: Int
    let className: String
    let startTime: String
    let trackCondition: String
    let purseText: String
    let aiConfidence: Int
    let paceTrend: [TrendPoint]
    let oddsMovement: [TrendPoint]
    let predictions: [PredictionPoint]
    let horses: [Horse]
    let suggestions: [AISuggestion]
}

nonisolated struct Horse: Identifiable, Hashable, Sendable {
    let id: UUID
    let number: Int
    let name: String
    let draw: Int
    let jockey: String
    let trainer: String
    let odds: Double
    let aiScore: Int
    let paceScore: Int
    let formScore: Int
    let bloodlineScore: Int
    let trackworkScore: Int
    let verdict: String
}

nonisolated struct TrendPoint: Identifiable, Hashable, Sendable {
    let id: UUID
    let label: String
    let value: Double
}

nonisolated struct PredictionPoint: Identifiable, Hashable, Sendable {
    let id: UUID
    let label: String
    let winProbability: Double
}

nonisolated struct AISuggestion: Identifiable, Hashable, Sendable {
    let id: UUID
    let title: String
    let picks: String
    let confidenceText: String
    let note: String
}

nonisolated struct AnalysisFactor: Identifiable, Hashable, Sendable {
    let id: UUID
    let name: String
    let weight: Int
    let summary: String
    let symbol: String
}

extension RaceMeeting {
    static let sample: RaceMeeting = {
        let raceThree = Race(
            id: UUID(),
            number: 3,
            title: "九龍金盃讓賽",
            distance: 1400,
            className: "Class 2",
            startTime: "15:10",
            trackCondition: "Good to Firm",
            purseText: "HK$2.84M",
            aiConfidence: 91,
            paceTrend: [
                TrendPoint(id: UUID(), label: "400m", value: 72),
                TrendPoint(id: UUID(), label: "800m", value: 78),
                TrendPoint(id: UUID(), label: "1000m", value: 81),
                TrendPoint(id: UUID(), label: "1200m", value: 88),
                TrendPoint(id: UUID(), label: "1400m", value: 92)
            ],
            oddsMovement: [
                TrendPoint(id: UUID(), label: "09:00", value: 8.2),
                TrendPoint(id: UUID(), label: "11:00", value: 7.4),
                TrendPoint(id: UUID(), label: "13:00", value: 6.6),
                TrendPoint(id: UUID(), label: "14:00", value: 5.9),
                TrendPoint(id: UUID(), label: "14:45", value: 5.2)
            ],
            predictions: [
                PredictionPoint(id: UUID(), label: "1號", winProbability: 31),
                PredictionPoint(id: UUID(), label: "4號", winProbability: 24),
                PredictionPoint(id: UUID(), label: "7號", winProbability: 18),
                PredictionPoint(id: UUID(), label: "9號", winProbability: 13),
                PredictionPoint(id: UUID(), label: "11號", winProbability: 8)
            ],
            horses: [
                Horse(id: UUID(), number: 1, name: "翠綠迅駒", draw: 4, jockey: "潘頓", trainer: "蔡約翰", odds: 5.2, aiScore: 95, paceScore: 92, formScore: 90, bloodlineScore: 84, trackworkScore: 88, verdict: "步速受惠，末段衝刺值最高"),
                Horse(id: UUID(), number: 4, name: "皇者飛鷹", draw: 7, jockey: "布文", trainer: "羅富全", odds: 6.1, aiScore: 91, paceScore: 86, formScore: 89, bloodlineScore: 87, trackworkScore: 90, verdict: "外檔仍具爆發力，配腳必要"),
                Horse(id: UUID(), number: 7, name: "金鎏星河", draw: 2, jockey: "何澤堯", trainer: "方嘉柏", odds: 8.8, aiScore: 88, paceScore: 84, formScore: 85, bloodlineScore: 91, trackworkScore: 83, verdict: "內檔省位，冷位可拖"),
                Horse(id: UUID(), number: 9, name: "勝利皇冠", draw: 10, jockey: "田泰安", trainer: "沈集成", odds: 11.4, aiScore: 82, paceScore: 79, formScore: 80, bloodlineScore: 78, trackworkScore: 84, verdict: "走勢穩定，四重彩邊線"),
                Horse(id: UUID(), number: 11, name: "龍騰天際", draw: 1, jockey: "艾道拿", trainer: "賀賢", odds: 14.0, aiScore: 78, paceScore: 76, formScore: 77, bloodlineScore: 82, trackworkScore: 80, verdict: "貼欄偷位，宜作保險"),
                Horse(id: UUID(), number: 12, name: "赤焰尊駒", draw: 12, jockey: "梁家俊", trainer: "大衛希斯", odds: 19.5, aiScore: 73, paceScore: 70, formScore: 74, bloodlineScore: 76, trackworkScore: 71, verdict: "需快步速配合，機會次選")
            ],
            suggestions: [
                AISuggestion(id: UUID(), title: "AI 1-2-3", picks: "1 / 4 / 7", confidenceText: "高信心 91%", note: "1號為主膽，4號作主要對手，7號拖冷腳"),
                AISuggestion(id: UUID(), title: "單T", picks: "膽 1、4｜腳 7、9、11、12", confidenceText: "穩健型", note: "以步速優勢配合近況熱度，適合保守組合"),
                AISuggestion(id: UUID(), title: "四重彩", picks: "1、4 / 1、4、7 / 1、4、7、9、11 / 全包冷門", confidenceText: "進取型", note: "前兩名集中，高位加入節奏受惠馬")
            ]
        )

        let raceSeven = Race(
            id: UUID(),
            number: 7,
            title: "天喜娛樂 AI 精選賽",
            distance: 1200,
            className: "Class 3",
            startTime: "17:20",
            trackCondition: "Good",
            purseText: "HK$1.86M",
            aiConfidence: 87,
            paceTrend: [
                TrendPoint(id: UUID(), label: "200m", value: 68),
                TrendPoint(id: UUID(), label: "400m", value: 79),
                TrendPoint(id: UUID(), label: "600m", value: 83),
                TrendPoint(id: UUID(), label: "800m", value: 89),
                TrendPoint(id: UUID(), label: "1200m", value: 86)
            ],
            oddsMovement: [
                TrendPoint(id: UUID(), label: "09:00", value: 10.6),
                TrendPoint(id: UUID(), label: "11:00", value: 9.8),
                TrendPoint(id: UUID(), label: "13:00", value: 8.9),
                TrendPoint(id: UUID(), label: "15:00", value: 8.0),
                TrendPoint(id: UUID(), label: "16:30", value: 7.3)
            ],
            predictions: [
                PredictionPoint(id: UUID(), label: "2號", winProbability: 28),
                PredictionPoint(id: UUID(), label: "5號", winProbability: 25),
                PredictionPoint(id: UUID(), label: "8號", winProbability: 19),
                PredictionPoint(id: UUID(), label: "10號", winProbability: 15),
                PredictionPoint(id: UUID(), label: "1號", winProbability: 9)
            ],
            horses: [
                Horse(id: UUID(), number: 2, name: "琥珀閃電", draw: 3, jockey: "霍宏聲", trainer: "韋達", odds: 7.3, aiScore: 90, paceScore: 88, formScore: 85, bloodlineScore: 82, trackworkScore: 90, verdict: "快閘快放，最適合短途節奏"),
                Horse(id: UUID(), number: 5, name: "御金名駒", draw: 5, jockey: "潘明輝", trainer: "呂健威", odds: 7.9, aiScore: 88, paceScore: 86, formScore: 87, bloodlineScore: 83, trackworkScore: 86, verdict: "連續上名型，穩陣配腳"),
                Horse(id: UUID(), number: 8, name: "翡翠疾風", draw: 11, jockey: "巴度", trainer: "蘇偉賢", odds: 10.4, aiScore: 84, paceScore: 81, formScore: 82, bloodlineScore: 80, trackworkScore: 85, verdict: "外檔衝刺馬，適合加入Q位")
            ],
            suggestions: [
                AISuggestion(id: UUID(), title: "騎師王推薦", picks: "2、5、8", confidenceText: "中高信心", note: "2號最合配速，5號近況穩，8號冷門值博"),
                AISuggestion(id: UUID(), title: "六環彩節選", picks: "2 / 2,5 / 2,5,8", confidenceText: "節奏主導", note: "本場建議集中三匹，不宜過度分散")
            ]
        )

        return RaceMeeting(
            id: UUID(),
            venue: "Sha Tin",
            title: "沙田日賽焦點",
            dateText: "16 Apr 2026 · Thu",
            surface: "Turf A Course",
            weather: "24°C · Slight Tailwind",
            highlight: "第三場為今日 AI 最強膽腳，天喜娛樂模型評為高流動資金聚焦場次。",
            races: [raceThree, raceSeven]
        )
    }()
}

extension AnalysisFactor {
    static let samples: [AnalysisFactor] = [
        AnalysisFactor(id: UUID(), name: "Draw", weight: 91, summary: "內檔於 1400 米有明顯節省腳程優勢。", symbol: "square.grid.3x3.fill"),
        AnalysisFactor(id: UUID(), name: "Pace", weight: 95, summary: "預測前段偏快，追前守中馬匹最受惠。", symbol: "speedometer"),
        AnalysisFactor(id: UUID(), name: "Form", weight: 88, summary: "近三仗末段分段穩定，狀態保持高位。", symbol: "waveform.path.ecg"),
        AnalysisFactor(id: UUID(), name: "Bloodline", weight: 79, summary: "父系對沙田 1400 米勝率偏高。", symbol: "point.3.connected.trianglepath.dotted"),
        AnalysisFactor(id: UUID(), name: "Trackwork", weight: 86, summary: "晨操最後 400 米反應銳利。", symbol: "figure.equestrian.sports"),
        AnalysisFactor(id: UUID(), name: "Odds Flow", weight: 83, summary: "資金持續流入，盤口走勢健康。", symbol: "chart.line.uptrend.xyaxis")
    ]
}
