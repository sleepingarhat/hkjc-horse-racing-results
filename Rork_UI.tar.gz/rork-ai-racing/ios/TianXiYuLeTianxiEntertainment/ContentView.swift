import SwiftUI

private enum AppTab: Hashable {
    case home
    case race
    case chat
    case factors
}

struct ContentView: View {
    @State private var viewModel = TianxiViewModel()
    @State private var selectedTab: AppTab = .home

    var body: some View {
        TabView(selection: $selectedTab) {
            Tab("首頁", systemImage: "house", value: .home) {
                NavigationStack {
                    HomeDashboardView(
                        viewModel: viewModel,
                        onOpenRace: { race in
                            viewModel.selectRace(race)
                            selectedTab = .race
                        },
                        onOpenChat: {
                            selectedTab = .chat
                        }
                    )
                    .navigationTitle("天喜娛樂")
                    .navigationBarTitleDisplayMode(.inline)
                }
            }

            Tab("賽事", systemImage: "flag.checkered.2.crossed", value: .race) {
                NavigationStack {
                    RaceDetailView(viewModel: viewModel)
                        .navigationTitle("Race Detail")
                        .navigationBarTitleDisplayMode(.inline)
                        .toolbar {
                            ToolbarItem(placement: .topBarTrailing) {
                                Menu {
                                    ForEach(viewModel.meeting.races) { race in
                                        Button("第\(race.number)場 \(race.title)") {
                                            viewModel.selectRace(race)
                                        }
                                    }
                                } label: {
                                    Image(systemName: "line.3.horizontal.decrease.circle")
                                        .foregroundStyle(TianxiPalette.gold)
                                }
                            }
                        }
                }
            }

            Tab("AI聊天", systemImage: "message", value: .chat) {
                NavigationStack {
                    AIChatView(viewModel: viewModel)
                        .navigationTitle("AI Analysis")
                        .navigationBarTitleDisplayMode(.inline)
                }
            }

            Tab("因子", systemImage: "slider.horizontal.3", value: .factors) {
                NavigationStack {
                    FactorAnalysisView(viewModel: viewModel)
                        .navigationTitle("Factors")
                        .navigationBarTitleDisplayMode(.inline)
                }
            }
        }
        .tint(TianxiPalette.gold)
        .preferredColorScheme(.dark)
    }
}

#Preview {
    ContentView()
}
