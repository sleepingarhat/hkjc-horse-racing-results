import SwiftUI

@main
struct TianXiYuLeTianxiEntertainmentApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
